package com.sadx.turbo;

import android.app.*;
import android.content.*;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ScreenRecordService extends Service {
  public static final String ACTION_START = "com.sadx.turbo.RECORD_START";
  public static final String ACTION_STOP = "com.sadx.turbo.RECORD_STOP";
  private static final String CHANNEL = "sadx_recording";
  private static ScreenRecordService active;
  private MediaProjection projection;
  private VirtualDisplay virtualDisplay;
  private MediaRecorder recorder;
  private boolean recording = false;

  @Override public void onCreate() { super.onCreate(); active = this; createChannel(); }

  @Override public int onStartCommand(Intent intent, int flags, int startId) {
    if (intent != null && ACTION_STOP.equals(intent.getAction())) { stopCapture(); stopSelf(); return START_NOT_STICKY; }
    if (intent == null) { stopSelf(); return START_NOT_STICKY; }
    startForeground(77, notification("Preparando gravação da tela"));
    int resultCode = intent.getIntExtra("resultCode", Activity.RESULT_CANCELED);
    Intent resultData = intent.getParcelableExtra("data");
    if (resultCode != Activity.RESULT_OK || resultData == null) { stopSelf(); return START_NOT_STICKY; }
    try { startCapture(resultCode, resultData); }
    catch (Exception e) { stopCapture(); stopSelf(); }
    return START_NOT_STICKY;
  }

  private void startCapture(int resultCode, Intent data) throws Exception {
    WindowManager wm = (WindowManager)getSystemService(WINDOW_SERVICE);
    DisplayMetrics metrics = new DisplayMetrics();
    if (Build.VERSION.SDK_INT >= 30) getDisplay().getRealMetrics(metrics); else wm.getDefaultDisplay().getRealMetrics(metrics);
    int width = metrics.widthPixels, height = metrics.heightPixels, density = metrics.densityDpi;
    File dir = new File(getExternalFilesDir(Environment.DIRECTORY_MOVIES), "SADX-TURBO");
    if (!dir.exists()) dir.mkdirs();
    String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
    File output = new File(dir, "SADX_" + stamp + ".mp4");

    recorder = new MediaRecorder();
    recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
    recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
    recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
    recorder.setVideoSize(width, height);
    recorder.setVideoFrameRate(60);
    recorder.setVideoEncodingBitRate(8 * 1000 * 1000);
    recorder.setOutputFile(output.getAbsolutePath());
    recorder.prepare();

    MediaProjectionManager manager = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
    projection = manager.getMediaProjection(resultCode, data);
    if (projection == null) throw new IllegalStateException("Permissão de captura não concedida");
    virtualDisplay = projection.createVirtualDisplay("SADX-TURBO", width, height, density,
      DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder.getSurface(), null, null);
    recorder.start();
    recording = true;
    updateNotification("Gravando tela • 60 FPS solicitado");
    sendState("recording", output.getAbsolutePath());
  }

  private void stopCapture() {
    if (recording && recorder != null) {
      try { recorder.stop(); } catch (Exception ignored) {}
      recording = false;
    }
    if (virtualDisplay != null) { virtualDisplay.release(); virtualDisplay = null; }
    if (recorder != null) { try { recorder.reset(); recorder.release(); } catch (Exception ignored) {} recorder = null; }
    if (projection != null) { projection.stop(); projection = null; }
    sendState("stopped", "");
  }

  private void sendState(String state, String path) {
    Intent i = new Intent("com.sadx.turbo.RECORD_STATE"); i.setPackage(getPackageName());
    i.putExtra("state", state); i.putExtra("path", path); sendBroadcast(i);
  }
  private void createChannel() {
    if (Build.VERSION.SDK_INT >= 26) {
      NotificationChannel c = new NotificationChannel(CHANNEL, "Gravação SADX TURBO", NotificationManager.IMPORTANCE_LOW);
      ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
    }
  }
  private Notification notification(String text) {
    Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
    return b.setContentTitle("SADX TURBO").setContentText(text).setSmallIcon(android.R.drawable.presence_video_online).setOngoing(true).build();
  }
  private void updateNotification(String text) { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(77, notification(text)); }
  @Override public void onDestroy() { stopCapture(); active = null; super.onDestroy(); }
  @Override public android.os.IBinder onBind(Intent intent) { return null; }
}
