package com.sadx.turbo;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.view.Display;
import android.view.View;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.util.Base64;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
  private static final int PICK_WALLPAPER = 41;
  private static final int REQUEST_RECORD = 42;
  private android.media.projection.MediaProjectionManager projectionManager;
  private WebView web;

  @Override public void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    getWindow().getDecorView().setSystemUiVisibility(
      View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
      View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    web = new WebView(this);
    web.setBackgroundColor(0xFF08090D);
    web.getSettings().setJavaScriptEnabled(true);
    web.setWebChromeClient(new WebChromeClient());
    web.setWebViewClient(new WebViewClient());
    web.addJavascriptInterface(new TurboBridge(), "AndroidTurbo");
    setContentView(web);
    web.loadUrl("file:///android_asset/index.html");
    projectionManager = (android.media.projection.MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
  }

  private class TurboBridge {
    @JavascriptInterface public void chooseWallpaper() {
      runOnUiThread(() -> {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        startActivityForResult(intent, PICK_WALLPAPER);
      });
    }
    @JavascriptInterface public void startRecording() {
      runOnUiThread(() -> {
        if (projectionManager != null) startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_RECORD);
        else web.evaluateJavascript("showNativeMessage(\'Gravação não disponível neste Android.\')", null);
      });
    }
    @JavascriptInterface public void stopRecording() {
      runOnUiThread(() -> {
        Intent stop = new Intent(MainActivity.this, ScreenRecordService.class); stop.setAction(ScreenRecordService.ACTION_STOP);
        startService(stop);
        web.evaluateJavascript("recordingChanged(false)", null);
      });
    }
    @JavascriptInterface public void applyMaxRefreshRate() {
      runOnUiThread(() -> {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
          Display display = getWindowManager().getDefaultDisplay();
          Display.Mode[] modes = display.getSupportedModes();
          Display.Mode best = null;
          for (Display.Mode mode : modes) {
            float hz = mode.getRefreshRate();
            if (hz <= 144.1f && (best == null || hz > best.getRefreshRate())) best = mode;
          }
          if (best != null) {
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.preferredDisplayModeId = best.getModeId();
            getWindow().setAttributes(params);
            web.evaluateJavascript("showNativeMessage('Solicitado: ' + " + best.getRefreshRate() + " + ' Hz. O sistema pode limitar a taxa.')", null);
          } else web.evaluateJavascript("showNativeMessage('Não foi encontrado modo de tela compatível até 144 Hz.')", null);
        } else web.evaluateJavascript("showNativeMessage('Este Android não permite selecionar o modo de tela pelo aplicativo.')", null);
      });
    }
  }

  @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    super.onActivityResult(requestCode, resultCode, data);
    if (requestCode == REQUEST_RECORD) {
      if (resultCode == RESULT_OK && data != null) {
        Intent service = new Intent(this, ScreenRecordService.class); service.setAction(ScreenRecordService.ACTION_START);
        service.putExtra("resultCode", resultCode); service.putExtra("data", data);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        if (web != null) web.evaluateJavascript("recordingChanged(true)", null);
      } else if (web != null) web.evaluateJavascript("showNativeMessage(\'Gravação cancelada.\')", null);
      return;
    }
    if (requestCode == PICK_WALLPAPER && resultCode == RESULT_OK && data != null) {
      Uri uri = data.getData();
      try {
        InputStream in = getContentResolver().openInputStream(uri);
        Bitmap bitmap = BitmapFactory.decodeStream(in);
        if (in != null) in.close();
        if (bitmap == null) throw new Exception("Imagem inválida");
        int max = 1600;
        float scale = Math.min(1f, max / (float)Math.max(bitmap.getWidth(), bitmap.getHeight()));
        Bitmap small = Bitmap.createScaledBitmap(bitmap, Math.round(bitmap.getWidth()*scale), Math.round(bitmap.getHeight()*scale), true);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        small.compress(Bitmap.CompressFormat.JPEG, 82, out);
        String encoded = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        web.evaluateJavascript("applyWallpaper('data:image/jpeg;base64," + encoded + "')", null);
      } catch (Exception e) {
        web.evaluateJavascript("showNativeMessage('Não foi possível abrir essa imagem.')", null);
      }
    }
  }
}
